//
// WARNING: You are not allowed to modify this file!
//
#include <iostream>
int main() {
if (0 == 0 && 1 == 1 && 1 == 1) {
std::cout << "simple test passed." << std::endl;
}
return 0;
}
